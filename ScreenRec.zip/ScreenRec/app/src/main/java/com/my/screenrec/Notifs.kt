package com.my.screenrec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon

object Notifs {
    const val CH_IDLE = "idle"
    const val CH_REC = "rec"
    const val ID_REC = 1
    const val ID_IDLE = 2

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_IDLE, "Ready", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_REC, "Recording", NotificationManager.IMPORTANCE_LOW)
        )
    }

    fun action(ctx: Context, icon: Int, title: String, pi: PendingIntent): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(ctx, icon), title, pi).build()

    /** Notification shown when not recording: has a Start button. */
    fun showIdle(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val startIntent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(MainActivity.EXTRA_AUTOSTART, true)
        val startPi = PendingIntent.getActivity(ctx, 10, startIntent, flags)

        val openIntent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val openPi = PendingIntent.getActivity(ctx, 11, openIntent, flags)

        val n = Notification.Builder(ctx, CH_IDLE)
            .setSmallIcon(R.drawable.ic_rec)
            .setContentTitle("Screen Recorder")
            .setContentText("Ready")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPi)
            .addAction(action(ctx, R.drawable.ic_play, "Start", startPi))
            .build()
        nm.notify(ID_IDLE, n)
    }

    fun cancelIdle(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(ID_IDLE)
    }
}
