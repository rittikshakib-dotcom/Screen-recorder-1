package com.my.screenrec

import android.content.Context
import android.content.SharedPreferences

/**
 * audioMode: 0 = mic only, 1 = internal only, 2 = mic + internal
 * orient:    0 = landscape, 1 = portrait, 2 = auto (follow screen)
 * gains: 1.0 = 100%
 */
data class Config(
    val shortSide: Int,
    val fps: Int,
    val orient: Int,
    val audioMode: Int,
    val micGain: Float,
    val intGain: Float
)

object Prefs {
    fun sp(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(ctx: Context): Config {
        val p = sp(ctx)
        return Config(
            shortSide = p.getInt("res", 1080),
            fps = p.getInt("fps", 60),
            orient = p.getInt("ori", 0),
            audioMode = p.getInt("audio", 2),
            micGain = p.getInt("mic", 100) / 100f,
            intGain = p.getInt("int", 100) / 100f
        )
    }
}
