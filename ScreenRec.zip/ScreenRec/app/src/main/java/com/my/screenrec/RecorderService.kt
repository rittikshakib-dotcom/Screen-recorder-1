package com.my.screenrec

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast

class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.my.screenrec.START"
        const val ACTION_PAUSE = "com.my.screenrec.PAUSE"
        const val ACTION_RESUME = "com.my.screenrec.RESUME"
        const val ACTION_STOP = "com.my.screenrec.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        @Volatile
        var active = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recorder: ScreenRecorder? = null
    private var projection: MediaProjection? = null
    private var stopping = false
    private var paused = false
    private var accumMs = 0L
    private var segStartMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording(intent)
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP -> stopRecording()
            else -> if (recorder == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    // ---------- start ----------

    private fun startRecording(intent: Intent) {
        if (recorder != null) return
        stopping = false
        val cfg = Prefs.load(this)

        paused = false
        accumMs = 0L
        segStartMs = SystemClock.elapsedRealtime()

        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (cfg.audioMode != 1 && Build.VERSION.SDK_INT >= 30) {
            types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        try {
            startForeground(Notifs.ID_REC, buildNotification(), types)
        } catch (e: Exception) {
            toast("Service start hoy nai: ${e.message}")
            stopSelf()
            return
        }
        Notifs.cancelIdle(this)

        try {
            val code = intent.getIntExtra(EXTRA_CODE, 0)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                ?: throw IllegalStateException("capture data nai")
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post { stopRecording() }
                }
            }, handler)
            projection = p

            val r = ScreenRecorder(this, p, cfg)
            r.start()
            recorder = r
            active = true
            if (r.fpsUsed != cfg.fps) {
                toast("${cfg.fps}fps phone support kore na, ${r.fpsUsed}fps e record hocche")
            }
        } catch (e: Exception) {
            toast("Record start hoy nai: ${e.message}")
            try { projection?.stop() } catch (_: Exception) {}
            projection = null
            recorder = null
            active = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            Notifs.showIdle(this)
            stopSelf()
        }
    }

    // ---------- pause / resume ----------

    private fun pauseRecording() {
        val r = recorder ?: return
        if (paused) return
        r.pause()
        accumMs += SystemClock.elapsedRealtime() - segStartMs
        paused = true
        refreshNotification()
    }

    private fun resumeRecording() {
        val r = recorder ?: return
        if (!paused) return
        r.resume()
        segStartMs = SystemClock.elapsedRealtime()
        paused = false
        refreshNotification()
    }

    // ---------- stop ----------

    private fun stopRecording() {
        if (stopping) return
        stopping = true
        val r = recorder
        val p = projection
        recorder = null
        Thread {
            try { r?.stop() } catch (_: Exception) {}
            handler.post {
                try { p?.stop() } catch (_: Exception) {}
                projection = null
                active = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                Notifs.showIdle(this)
                if (r != null) toast("Saved: Movies/ScreenRec")
                stopSelf()
            }
        }.start()
    }

    override fun onDestroy() {
        active = false
        super.onDestroy()
    }

    // ---------- notification ----------

    private fun servicePi(action: String, req: Int): PendingIntent =
        PendingIntent.getService(
            this, req,
            Intent(this, RecorderService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildNotification(): Notification {
        val openPi = PendingIntent.getActivity(
            this, 20,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, Notifs.CH_REC)
            .setSmallIcon(R.drawable.ic_rec)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPi)

        if (paused) {
            b.setContentTitle("Paused")
                .setContentText("Recording paused")
                .setShowWhen(false)
                .addAction(Notifs.action(this, R.drawable.ic_play, "Resume", servicePi(ACTION_RESUME, 31)))
        } else {
            val elapsed = accumMs + (SystemClock.elapsedRealtime() - segStartMs)
            b.setContentTitle("Recording")
                .setContentText("Screen recording cholche")
                .setUsesChronometer(true)
                .setShowWhen(true)
                .setWhen(System.currentTimeMillis() - elapsed)
                .addAction(Notifs.action(this, R.drawable.ic_pause, "Pause", servicePi(ACTION_PAUSE, 30)))
        }
        b.addAction(Notifs.action(this, R.drawable.ic_stop, "Stop", servicePi(ACTION_STOP, 32)))
        return b.build()
    }

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(Notifs.ID_REC, buildNotification())
    }

    private fun toast(msg: String) {
        handler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }
}
