package com.my.screenrec

import android.content.ContentValues
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Surface
import android.view.WindowManager
import java.text.SimpleDateFormat
import java.util.Arrays
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Screen (H.264) + audio (AAC) recorder.
 * Audio sources: mic, internal (AudioPlaybackCapture, Android 10+), or both mixed
 * with separate volume gains.
 */
class ScreenRecorder(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val cfg: Config
) {
    companion object {
        private const val SR = 44100
        private const val CHUNK = 1024 // audio frames per chunk
        private const val MIME_V = MediaFormat.MIMETYPE_VIDEO_AVC
    }

    var fpsUsed: Int = cfg.fps
        private set

    private var videoEnc: MediaCodec? = null
    private var audioEnc: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var display: VirtualDisplay? = null
    private var surface: Surface? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var micRec: AudioRecord? = null
    private var intRec: AudioRecord? = null
    private var videoThread: Thread? = null
    private var audioThread: Thread? = null

    private val lock = Any()
    private val muxerReady = CountDownLatch(1)
    private var muxerStarted = false
    private var videoTrack = -1
    private var audioTrack = -1
    private var wroteAny = false
    private var lastVideoPts = -1L
    private var lastAudioPts = -1L

    @Volatile private var paused = false
    @Volatile private var stopRequested = false
    @Volatile private var needKey = false
    @Volatile private var baseUs = 0L
    @Volatile private var pausedTotalUs = 0L
    @Volatile private var pauseStartUs = 0L

    private fun nowUs() = System.nanoTime() / 1000

    // ======================= public API =======================

    fun start() {
        try {
            val (w, h) = computeSize()
            createOutput()
            fpsUsed = setupVideo(w, h)
            setupAudio()
            muxer = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            baseUs = nowUs()

            val dpi = ctx.resources.displayMetrics.densityDpi
            display = projection.createVirtualDisplay(
                "ScreenRec", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                surface, null, null
            )

            micRec?.startRecording()
            intRec?.startRecording()

            videoThread = Thread({ videoLoop() }, "rec-video").also { it.start() }
            audioThread = Thread({ audioLoop() }, "rec-audio").also { it.start() }
        } catch (e: Exception) {
            stopRequested = true
            releaseAll(delete = true)
            throw e
        }
    }

    fun pause() {
        if (paused || stopRequested) return
        pauseStartUs = nowUs()
        paused = true
    }

    fun resume() {
        if (!paused) return
        pausedTotalUs += nowUs() - pauseStartUs
        needKey = true
        try {
            val b = Bundle()
            b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            videoEnc?.setParameters(b)
        } catch (_: Exception) {}
        paused = false
    }

    fun stop() {
        if (stopRequested) return
        stopRequested = true
        try { display?.release() } catch (_: Exception) {}
        try { videoEnc?.signalEndOfInputStream() } catch (_: Exception) {}
        try { audioThread?.join(6000) } catch (_: Exception) {}
        try { videoThread?.join(6000) } catch (_: Exception) {}
        synchronized(lock) {
            try {
                if (muxerStarted) muxer?.stop()
            } catch (_: Exception) {
                wroteAny = false
            }
        }
        releaseAll(delete = !wroteAny)
    }

    // ======================= setup =======================

    @Suppress("DEPRECATION")
    private fun computeSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        ctx.getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(dm)
        val dw = dm.widthPixels
        val dh = dm.heightPixels
        val devLong = max(dw, dh).toFloat()
        val devShort = min(dw, dh).toFloat()

        val shortSide = cfg.shortSide - cfg.shortSide % 2
        var longSide = (shortSide * devLong / devShort).roundToInt()
        longSide -= longSide % 2

        val landscape = when (cfg.orient) {
            0 -> true
            1 -> false
            else -> dw >= dh
        }
        return if (landscape) Pair(longSide, shortSide) else Pair(shortSide, longSide)
    }

    private fun createOutput() {
        val name = "REC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ScreenRec")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val u = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Output file banano jay nai")
        uri = u
        pfd = ctx.contentResolver.openFileDescriptor(u, "rw")
            ?: throw IllegalStateException("Output file khola jay nai")
    }

    /** Tries the chosen fps first, then falls back to 60 and 30. Returns the fps used. */
    private fun setupVideo(w: Int, h: Int): Int {
        val tries = listOf(cfg.fps, 60, 30).filter { it <= cfg.fps }.distinct()
        var last: Exception? = null
        for (f in tries) {
            var enc: MediaCodec? = null
            try {
                val bitrate = (w.toLong() * h * f * 0.1).toLong()
                    .coerceIn(2_000_000L, 60_000_000L).toInt()
                val fmt = MediaFormat.createVideoFormat(MIME_V, w, h).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT,
                        MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                    setInteger(MediaFormat.KEY_FRAME_RATE, f)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                    setInteger(MediaFormat.KEY_BITRATE_MODE,
                        MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                    setInteger(MediaFormat.KEY_PRIORITY, 0)
                }
                enc = MediaCodec.createEncoderByType(MIME_V)
                enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                surface = enc.createInputSurface()
                enc.start()
                videoEnc = enc
                return f
            } catch (e: Exception) {
                last = e
                try { enc?.release() } catch (_: Exception) {}
                surface = null
            }
        }
        throw last ?: IllegalStateException("Video encoder start hoy nai")
    }

    private fun setupAudio() {
        val mode = cfg.audioMode
        val stereo = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SR)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val mono = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SR)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        if (mode == 0 || mode == 2) {
            val min = AudioRecord.getMinBufferSize(
                SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            micRec = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(mono)
                .setBufferSizeInBytes(max(min * 4, 32768))
                .build()
            if (micRec!!.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("Microphone start hoy nai")
            }
        }
        if (mode == 1 || mode == 2) {
            val pc = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val min = AudioRecord.getMinBufferSize(
                SR, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            intRec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(pc)
                .setAudioFormat(stereo)
                .setBufferSizeInBytes(max(min * 4, 65536))
                .build()
            if (intRec!!.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("Internal audio capture start hoy nai")
            }
        }

        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        audioEnc = enc
    }

    // ======================= video thread =======================

    private fun videoLoop() {
        val enc = videoEnc ?: return
        val info = MediaCodec.BufferInfo()
        var stopAt = 0L
        try {
            while (true) {
                if (stopRequested && stopAt == 0L) stopAt = System.nanoTime() + 4_000_000_000L
                if (stopAt != 0L && System.nanoTime() > stopAt) break

                val idx = enc.dequeueOutputBuffer(info, 10_000)
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    addTrack(true, enc.outputFormat)
                } else if (idx >= 0) {
                    val buf = enc.getOutputBuffer(idx)
                    val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && buf != null && !paused) {
                        val isKey = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                        if (!needKey || isKey) {
                            needKey = false
                            writeSample(true, buf, info)
                        }
                    }
                    enc.releaseOutputBuffer(idx, false)
                    if (eos) break
                }
            }
        } catch (_: Exception) {
        }
    }

    // ======================= audio thread =======================

    private fun readFully(rec: AudioRecord, buf: ShortArray, n: Int): Boolean {
        var off = 0
        while (off < n && !stopRequested) {
            val r = rec.read(buf, off, n - off)
            if (r < 0) {
                Arrays.fill(buf, off, n, 0.toShort())
                return false
            }
            off += r
        }
        return true
    }

    private fun audioLoop() {
        val micBuf = ShortArray(CHUNK)
        val intBuf = ShortArray(CHUNK * 2)
        val out = ByteArray(CHUNK * 4)
        val chunkUs = CHUNK * 1_000_000L / SR

        var segStartUs = nowUs()
        var samples = 0L
        var wasPaused = false

        try {
            while (!stopRequested) {
                var ok = true
                intRec?.let { if (!readFully(it, intBuf, CHUNK * 2)) ok = false }
                micRec?.let { if (!readFully(it, micBuf, CHUNK)) ok = false }
                if (!ok) Thread.sleep(chunkUs / 1000)
                if (stopRequested) break

                if (paused) {
                    wasPaused = true
                    continue
                }
                if (wasPaused) {
                    segStartUs = nowUs() - chunkUs
                    samples = 0
                    wasPaused = false
                }

                // mix to 16-bit stereo little-endian
                val mg = cfg.micGain
                val ig = cfg.intGain
                for (i in 0 until CHUNK) {
                    var l = 0f
                    var r = 0f
                    if (intRec != null) {
                        l += intBuf[2 * i] * ig
                        r += intBuf[2 * i + 1] * ig
                    }
                    if (micRec != null) {
                        val m = micBuf[i] * mg
                        l += m
                        r += m
                    }
                    val li = l.coerceIn(-32768f, 32767f).toInt()
                    val ri = r.coerceIn(-32768f, 32767f).toInt()
                    out[4 * i] = (li and 0xFF).toByte()
                    out[4 * i + 1] = ((li shr 8) and 0xFF).toByte()
                    out[4 * i + 2] = (ri and 0xFF).toByte()
                    out[4 * i + 3] = ((ri shr 8) and 0xFF).toByte()
                }

                val wallUs = segStartUs + samples * 1_000_000L / SR
                samples += CHUNK
                val ptsUs = max(0L, wallUs - baseUs - pausedTotalUs)
                feedAudio(out, out.size, ptsUs)
            }
        } catch (_: Exception) {
        }
        try { finishAudio() } catch (_: Exception) {}
    }

    private fun feedAudio(data: ByteArray, len: Int, ptsUs: Long) {
        val enc = audioEnc ?: return
        var offset = 0
        while (offset < len) {
            val idx = enc.dequeueInputBuffer(10_000)
            if (idx < 0) {
                drainAudio(false)
                continue
            }
            val buf = enc.getInputBuffer(idx) ?: return
            buf.clear()
            val n = min(buf.remaining(), len - offset)
            buf.put(data, offset, n)
            val p = ptsUs + (offset / 4) * 1_000_000L / SR
            enc.queueInputBuffer(idx, 0, n, p, 0)
            offset += n
            drainAudio(false)
        }
    }

    private fun finishAudio() {
        val enc = audioEnc ?: return
        val deadline = System.nanoTime() + 3_000_000_000L
        var queued = false
        while (!queued && System.nanoTime() < deadline) {
            val idx = enc.dequeueInputBuffer(10_000)
            if (idx >= 0) {
                enc.queueInputBuffer(
                    idx, 0, 0,
                    max(0L, nowUs() - baseUs - pausedTotalUs),
                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                )
                queued = true
            } else {
                drainAudio(false)
            }
        }
        val deadline2 = System.nanoTime() + 3_000_000_000L
        while (System.nanoTime() < deadline2) {
            if (drainAudio(true)) break
        }
    }

    /** Returns true once end-of-stream was seen. */
    private fun drainAudio(wait: Boolean): Boolean {
        val enc = audioEnc ?: return true
        val info = MediaCodec.BufferInfo()
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, if (wait) 10_000 else 0)
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                addTrack(false, enc.outputFormat)
            } else if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                return false
            } else if (idx >= 0) {
                val buf = enc.getOutputBuffer(idx)
                val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                if (info.size > 0 && buf != null) writeSample(false, buf, info)
                enc.releaseOutputBuffer(idx, false)
                if (eos) return true
            }
        }
    }

    // ======================= muxer helpers =======================

    private fun addTrack(video: Boolean, format: MediaFormat) {
        synchronized(lock) {
            val m = muxer ?: return
            val t = m.addTrack(format)
            if (video) videoTrack = t else audioTrack = t
            if (videoTrack >= 0 && audioTrack >= 0 && !muxerStarted) {
                m.start()
                muxerStarted = true
                muxerReady.countDown()
            }
        }
    }

    private fun writeSample(video: Boolean, buf: java.nio.ByteBuffer, info: MediaCodec.BufferInfo) {
        if (!muxerStarted) {
            try { muxerReady.await(5, TimeUnit.SECONDS) } catch (_: InterruptedException) {}
        }
        synchronized(lock) {
            if (!muxerStarted) return
            var pts = if (video) info.presentationTimeUs - baseUs - pausedTotalUs
            else info.presentationTimeUs
            if (pts < 0) pts = 0
            val last = if (video) lastVideoPts else lastAudioPts
            if (pts <= last) pts = last + 1
            if (video) lastVideoPts = pts else lastAudioPts = pts
            info.presentationTimeUs = pts
            buf.position(info.offset)
            buf.limit(info.offset + info.size)
            muxer?.writeSampleData(if (video) videoTrack else audioTrack, buf, info)
            wroteAny = true
        }
    }

    // ======================= cleanup =======================

    private fun releaseAll(delete: Boolean) {
        try { display?.release() } catch (_: Exception) {}
        try { micRec?.stop() } catch (_: Exception) {}
        try { micRec?.release() } catch (_: Exception) {}
        try { intRec?.stop() } catch (_: Exception) {}
        try { intRec?.release() } catch (_: Exception) {}
        try { videoEnc?.stop() } catch (_: Exception) {}
        try { videoEnc?.release() } catch (_: Exception) {}
        try { audioEnc?.stop() } catch (_: Exception) {}
        try { audioEnc?.release() } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        display = null; micRec = null; intRec = null
        videoEnc = null; audioEnc = null; surface = null; muxer = null; pfd = null

        val u = uri
        if (u != null) {
            try {
                if (delete) {
                    ctx.contentResolver.delete(u, null, null)
                } else {
                    val v = ContentValues()
                    v.put(MediaStore.Video.Media.IS_PENDING, 0)
                    ctx.contentResolver.update(u, v, null, null)
                }
            } catch (_: Exception) {}
        }
        uri = null
    }
}
