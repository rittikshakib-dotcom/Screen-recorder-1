package com.my.screenrec

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        const val EXTRA_AUTOSTART = "autostart"
        private const val REQ_PERM_INIT = 1
        private const val REQ_PERM_START = 2
        private const val REQ_CAPTURE = 3
    }

    // Resolution = short side of the video (400p ... 1080p)
    private val resList = intArrayOf(400, 480, 540, 600, 720, 800, 900, 1000, 1080)
    private val fpsList = intArrayOf(24, 30, 45, 60, 90, 120)
    private val oriList = listOf("Landscape", "Portrait", "Auto (follow screen)")

    private lateinit var spRes: Spinner
    private lateinit var spFps: Spinner
    private lateinit var spOri: Spinner
    private lateinit var rgAudio: RadioGroup
    private lateinit var boxMic: View
    private lateinit var boxInt: View
    private lateinit var tvMic: TextView
    private lateinit var tvInt: TextView
    private lateinit var sbMic: SeekBar
    private lateinit var sbInt: SeekBar
    private lateinit var btnStart: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spRes = findViewById(R.id.spRes)
        spFps = findViewById(R.id.spFps)
        spOri = findViewById(R.id.spOri)
        rgAudio = findViewById(R.id.rgAudio)
        boxMic = findViewById(R.id.boxMic)
        boxInt = findViewById(R.id.boxInt)
        tvMic = findViewById(R.id.tvMic)
        tvInt = findViewById(R.id.tvInt)
        sbMic = findViewById(R.id.sbMic)
        sbInt = findViewById(R.id.sbInt)
        btnStart = findViewById(R.id.btnStart)

        spRes.adapter = adapter(resList.map { "${it}p" })
        spFps.adapter = adapter(fpsList.map { "$it fps" })
        spOri.adapter = adapter(oriList)

        loadSettings()
        updateAudioUi()

        sbMic.setOnSeekBarChangeListener(seekListener { updateAudioUi() })
        sbInt.setOnSeekBarChangeListener(seekListener { updateAudioUi() })
        rgAudio.setOnCheckedChangeListener { _, _ -> updateAudioUi() }
        btnStart.setOnClickListener { beginFlow() }

        Notifs.createChannels(this)
        ensureInitialPermissions()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (!RecorderService.active) Notifs.showIdle(this)
    }

    override fun onPause() {
        super.onPause()
        saveSettings()
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_AUTOSTART, false) == true) {
            i.removeExtra(EXTRA_AUTOSTART)
            beginFlow()
        }
    }

    // ---------- UI helpers ----------

    private fun adapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun seekListener(f: () -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = f()
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun audioMode(): Int = when (rgAudio.checkedRadioButtonId) {
        R.id.rbMic -> 0
        R.id.rbInt -> 1
        else -> 2
    }

    private fun updateAudioUi() {
        val mode = audioMode()
        boxMic.visibility = if (mode == 0 || mode == 2) View.VISIBLE else View.GONE
        boxInt.visibility = if (mode == 1 || mode == 2) View.VISIBLE else View.GONE
        tvMic.text = "Microphone volume: ${sbMic.progress}%"
        tvInt.text = "Internal volume: ${sbInt.progress}%"
    }

    private fun loadSettings() {
        val c = Prefs.load(this)
        spRes.setSelection(resList.indexOf(c.shortSide).coerceAtLeast(0))
        spFps.setSelection(fpsList.indexOf(c.fps).coerceAtLeast(0))
        spOri.setSelection(c.orient.coerceIn(0, 2))
        rgAudio.check(
            when (c.audioMode) {
                0 -> R.id.rbMic
                1 -> R.id.rbInt
                else -> R.id.rbBoth
            }
        )
        sbMic.progress = (c.micGain * 100).toInt()
        sbInt.progress = (c.intGain * 100).toInt()
    }

    private fun saveSettings() {
        Prefs.sp(this).edit()
            .putInt("res", resList[spRes.selectedItemPosition])
            .putInt("fps", fpsList[spFps.selectedItemPosition])
            .putInt("ori", spOri.selectedItemPosition)
            .putInt("audio", audioMode())
            .putInt("mic", sbMic.progress)
            .putInt("int", sbInt.progress)
            .apply()
    }

    // ---------- Permissions + capture flow ----------

    private fun missingPermissions(): Array<String> {
        val list = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            list.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        return list.toTypedArray()
    }

    private fun ensureInitialPermissions() {
        val missing = missingPermissions()
        if (missing.isNotEmpty()) requestPermissions(missing, REQ_PERM_INIT)
    }

    private fun beginFlow() {
        saveSettings()
        val missing = missingPermissions()
        if (missing.isNotEmpty()) {
            requestPermissions(missing, REQ_PERM_START)
        } else {
            requestCapture()
        }
    }

    private fun requestCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Notifs.showIdle(this)
        if (requestCode == REQ_PERM_START) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    Toast.makeText(this, "Notification allow na korle button dekhbe na", Toast.LENGTH_LONG).show()
                }
                requestCapture()
            } else {
                Toast.makeText(this, "Microphone permission dorkar", Toast.LENGTH_LONG).show()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, RecorderService::class.java)
                    .setAction(RecorderService.ACTION_START)
                    .putExtra(RecorderService.EXTRA_CODE, resultCode)
                    .putExtra(RecorderService.EXTRA_DATA, data)
                startForegroundService(i)
                finish()
            } else {
                Toast.makeText(this, "Screen capture permission deya hoy nai", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
